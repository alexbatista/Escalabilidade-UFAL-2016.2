import requests

def handler(event, context):
    try:
        payload = {'host': event['host'],'totalRequests': event['totalRequests'],'distributionType':event['distributionType'],'email':event['email'],'testName':event['testName']}
        req = requests.post('http://172.31.12.119/start', data=payload, timeout=3) #use private IP
        return payload
    except requests.exceptions.Timeout:
        return "A timeout error occurred"
    except requests.exceptions.TooManyRedirects:
        return "This URL trigger many redirections, try a different one"
    except requests.exceptions.RequestException as e:
        return "Catastrophic error"+str(e)+"\n"
